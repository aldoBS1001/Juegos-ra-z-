import {BadRequestException,Body,Controller,Get,Headers,Param,Post} from '@nestjs/common';
import {BlockchainService} from './service';
import {Network} from './types';

@Controller()
export class BlockchainController {
  constructor(private readonly svc:BlockchainService){}
  private async safe<T>(f:()=>T|Promise<T>){try{return await f();}catch(e){throw new BadRequestException({code:e instanceof Error?e.message:'BLOCKCHAIN_ERROR'});}}
  @Post('wallet/challenge') challenge(@Body() b:{network:Network;address:string;sessionId:string}){return this.safe(()=>this.svc.challenge(b.network,b.address,b.sessionId));}
  @Post('wallet/verify') verify(@Body() b:{challengeId:string;sessionId:string;signature:string;publicKey?:string}){return this.safe(()=>this.svc.verify(b.challengeId,b.sessionId,b.signature,b.publicKey));}
  @Get('wallet/balance/:network/:address') balance(@Param('network') network:Network,@Param('address') address:string){return this.safe(async()=>({network,address,balance:await this.svc.balance(network,address)}));}
  @Post('transaction/create') create(@Headers('idempotency-key') key:string,@Body() b:{network:Network;from:string;to:string;amount:string}){if(!key)throw new BadRequestException({code:'IDEMPOTENCY_KEY_REQUIRED'});return this.safe(()=>this.svc.create(b.network,b.from,b.to,b.amount,key));}
  @Post('transaction/submit') submit(@Body() b:{transactionId:string;signedTransaction:unknown}){return this.safe(()=>this.svc.submit(b.transactionId,b.signedTransaction));}
  @Post('transaction/broadcast') broadcast(@Body() b:{transactionId:string;signedTransaction:unknown}){return this.safe(()=>this.svc.submit(b.transactionId,b.signedTransaction));}
  @Get('transaction/status/:id') status(@Param('id') id:string){return this.safe(()=>this.svc.status(id));}
  @Get('transaction/:id/status') statusCanonical(@Param('id') id:string){return this.safe(()=>this.svc.status(id));}
  @Get('transaction/:id') get(@Param('id') id:string){return this.safe(()=>this.svc.status(id));}
  @Post('transaction/:id/verify') verifyRecord(@Param('id') id:string){return this.safe(()=>this.svc.verifyRecord(id));}
  @Post('transaction/verify') verifyTx(@Body() b:{network:Network;hash:string}){return this.safe(()=>this.svc.verifyTransaction(b.network,b.hash));}
  @Get('admin/blockchain/operations') operations(){return this.svc.operations();}
  @Get('admin/blockchain/status') statusAll(){return this.svc.health();}
}
