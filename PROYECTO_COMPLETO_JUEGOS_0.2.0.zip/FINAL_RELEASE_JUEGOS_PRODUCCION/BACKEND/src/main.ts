import 'reflect-metadata';
import helmet from 'helmet';
import { Module, Controller, Get, Post, Body, Param, ForbiddenException, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { WebSocketGateway, WebSocketServer, SubscribeMessage, ConnectedSocket, MessageBody, OnGatewayConnection } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { randomInt, randomUUID } from 'node:crypto';
import {BlockchainController} from './blockchain/controller';
import {BlockchainService} from './blockchain/service';

type GameType = 'LOTERIA'|'TOMA_TODO'|'DOMINO';
type Player = { id:string; name:string; connected:boolean };
type Room = { id:string; code:string; game:GameType; ownerId:string; status:'LOBBY'|'PLAYING'|'FINISHED'; players:Player[]; seq:number; state:Record<string,unknown>; createdAt:string };
const rooms = new Map<string,Room>();
const socialOnly = process.env.REAL_MONEY_ENABLED !== 'true';

function shuffle<T>(source:T[]):T[]{ const a=[...source]; for(let i=a.length-1;i>0;i--){const j=randomInt(i+1);[a[i],a[j]]=[a[j],a[i]];} return a; }
function publicRoom(room:Room){ return {...room, socialOnly:true, moneyFeatures:false}; }
function createRoom(game:GameType, ownerId:string, name:string):Room {
  const id=randomUUID(); const code=randomUUID().replace(/-/g,'').slice(0,6).toUpperCase();
  const room:Room={id,code,game,ownerId,status:'LOBBY',players:[{id:ownerId,name,connected:true}],seq:0,state:{},createdAt:new Date().toISOString()}; rooms.set(id,room); return room;
}

@Controller()
class ApiController {
  @Get('health') health(){return {ok:true,mode:'SOCIAL_FREE',moneyFeatures:false,time:new Date().toISOString()};}
  @Get('rooms/:id') room(@Param('id') id:string){const r=rooms.get(id); return r?publicRoom(r):{error:'ROOM_NOT_FOUND'};}
  @Get('rooms/code/:code') roomByCode(@Param('code') code:string){
    const normalized=code.trim().toUpperCase();
    const r=[...rooms.values()].find(room=>room.code===normalized);
    return r?publicRoom(r):{error:'ROOM_NOT_FOUND'};
  }
  @Post('rooms') make(@Body() b:{game:GameType;ownerId:string;name:string}){return publicRoom(createRoom(b.game,b.ownerId,b.name));}
  @Post('money/:action') blocked(@Param('action') action:string){throw new ForbiddenException({code:'MONEY_FEATURES_DISABLED',action,message:'MVP social gratuito'});}
}

@WebSocketGateway({cors:{origin:true,credentials:true},namespace:'/game'})
class GameGateway implements OnGatewayConnection {
  @WebSocketServer() io!:Server;
  handleConnection(socket:Socket){socket.emit('system:mode',{mode:'SOCIAL_FREE',moneyFeatures:false});}
  emitState(r:Room){r.seq++; this.io.to(r.id).emit('room:state',publicRoom(r));}
  @SubscribeMessage('room:join') join(@ConnectedSocket() s:Socket,@MessageBody() b:{roomId:string;userId:string;name:string}){
    const r=rooms.get(b.roomId); if(!r)return {ok:false,error:'ROOM_NOT_FOUND'}; s.join(r.id);
    const p=r.players.find(x=>x.id===b.userId); p?p.connected=true:r.players.push({id:b.userId,name:b.name,connected:true}); this.emitState(r); return {ok:true,snapshot:publicRoom(r)};
  }
  @SubscribeMessage('room:resume') resume(@ConnectedSocket() s:Socket,@MessageBody() b:{roomId:string;lastSeq:number}){
    const r=rooms.get(b.roomId); if(!r)return {ok:false,error:'ROOM_NOT_FOUND'}; s.join(r.id); return {ok:true,snapshot:publicRoom(r),missed:r.seq>b.lastSeq};
  }
  @SubscribeMessage('game:start') start(@MessageBody() b:{roomId:string;userId:string}){
    const r=rooms.get(b.roomId); if(!r||r.ownerId!==b.userId)return {ok:false,error:'NOT_OWNER'}; if(r.players.length<4)return {ok:false,error:'MIN_FOUR_PLAYERS'};
    r.status='PLAYING';
    if(r.game==='LOTERIA') r.state={deck:shuffle(Array.from({length:54},(_,i)=>i+1)),drawn:[],pattern:'FULL'};
    if(r.game==='TOMA_TODO') r.state={turn:0,history:[],pot:0};
    if(r.game==='DOMINO') r.state={turn:0,board:[],hands:Object.fromEntries(r.players.slice(0,4).map(p=>[p.id,[]]))};
    this.emitState(r); return {ok:true};
  }
  @SubscribeMessage('loteria:draw') draw(@MessageBody() b:{roomId:string;userId:string}){
    const r=rooms.get(b.roomId); if(!r||r.game!=='LOTERIA'||r.ownerId!==b.userId)return {ok:false,error:'DENIED'};
    const deck=r.state.deck as number[], drawn=r.state.drawn as number[]; const card=deck.shift(); if(card)drawn.push(card); this.emitState(r); return {ok:true,card};
  }
  @SubscribeMessage('toma:spin') spin(@MessageBody() b:{roomId:string;userId:string}){
    const r=rooms.get(b.roomId); if(!r||r.game!=='TOMA_TODO')return {ok:false,error:'DENIED'}; const turn=r.state.turn as number;
    if(r.players[turn]?.id!==b.userId)return {ok:false,error:'NOT_YOUR_TURN'};
    const outcomes=['TOMA 1','TOMA 2','TOMA 3','PON 1','PON 2','PON 3','TODOS PONEN','TOMA TODO']; const outcome=outcomes[randomInt(outcomes.length)];
    (r.state.history as string[]).push(outcome); r.state.turn=(turn+1)%r.players.length; this.emitState(r); return {ok:true,outcome};
  }
}

@Module({controllers:[ApiController,BlockchainController],providers:[GameGateway,BlockchainService]}) class AppModule{}
async function bootstrap(){const app=await NestFactory.create(AppModule);app.use(helmet());app.enableCors({origin:true,credentials:true});app.useGlobalPipes(new ValidationPipe({whitelist:true,transform:true}));await app.listen(Number(process.env.API_PORT||4000),'0.0.0.0');}
bootstrap();
