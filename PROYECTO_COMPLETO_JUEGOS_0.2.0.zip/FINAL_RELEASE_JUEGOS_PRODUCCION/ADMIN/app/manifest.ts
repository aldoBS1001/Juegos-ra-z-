import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Juegos Raíz — Panel Administrativo',
    short_name: 'Juegos Raíz Admin',
    description: 'Panel administrativo separado para Juegos Raíz.',
    start_url: '/',
    display: 'standalone',
    background_color: '#fff9f0',
    theme_color: '#3b2730',
  };
}
