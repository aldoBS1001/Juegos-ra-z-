import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
export default function Layout(){return <><StatusBar style="dark"/><Stack screenOptions={{headerStyle:{backgroundColor:'#F7EBD8'},headerTintColor:'#3B2730',contentStyle:{backgroundColor:'#FFF9F0'}}}/></>}
