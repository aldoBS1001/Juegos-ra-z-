export const OUTCOMES=['TOMA 1','TOMA 2','TOMA 3','PON 1','PON 2','PON 3','TODOS PONEN','TOMA TODO'] as const;
export function hasWon(card:number[],drawn:number[],pattern:'LINE'|'CORNERS'|'FULL'){
 const hit=new Set(drawn); if(card.length!==30)return false;
 if(pattern==='FULL')return card.every(x=>hit.has(x));
 if(pattern==='CORNERS')return [0,5,24,29].every(i=>hit.has(card[i]));
 return Array.from({length:5},(_,r)=>card.slice(r*6,r*6+6).every(x=>hit.has(x))).some(Boolean);
}
export function commission(gross:number,bps=1000){if(gross<0||bps<0||bps>3000)throw new Error('INVALID_AMOUNT');const fee=Math.round(gross*bps)/10000;return {gross,fee,net:gross-fee};}
export function legalDominoMove(tile:[number,number],ends:[number,number]|null){return !ends||tile.includes(ends[0])||tile.includes(ends[1]);}
