# QA, operación y publicación

## Puertas de calidad

1. Unitarias: reglas, patrones, turnos, validadores y comisiones futuras.
2. Integración: REST, Socket.IO, PostgreSQL, Redis y reconexión.
3. E2E: crear sala → cuatro usuarios → partida → resultado → historial.
4. Carga: k6 con 1,000 sockets/evento y 10 eventos; fallos de nodo y Redis.
5. Móvil: iPhone SE/15/15 Pro Max/iPad y Android gama baja/media/tablet, red degradada y segundo plano.
6. Seguridad: SAST, dependencias, secretos, DAST, pentest y threat model.
7. Accesibilidad: VoiceOver, TalkBack, contraste, texto 200% y switch control.

Las “pruebas en dispositivos reales” requieren hardware o un device farm y cuentas externas; no pueden certificarse sólo desde este repositorio. Registrar evidencia por build, dispositivo, sistema y caso.

## TestFlight

1. Sustituir `mx.juegosraiz.app` y `REPLACE_WITH_EAS_PROJECT_ID` por los valores del titular.
2. Configurar Apple Developer, App Store Connect, política de privacidad y soporte.
3. `cd apps/mobile && eas build --profile preview --platform ios`.
4. Validar en dispositivos; crear build production y `eas submit --platform ios`.
5. Declarar que el binario es social/gratuito y verificar que no contiene rutas económicas.

## Google Play interno

1. Crear aplicación y firma administrada; configurar ficha, Data Safety y testers.
2. `eas build --profile preview --platform android`.
3. Subir AAB a Internal testing o usar `eas submit --platform android`.
4. Ejecutar pre-launch report y cerrar fallos críticos.

## Deep links, QR y push

La app declara esquema `juegosraiz://` y App Links. En producción publicar `apple-app-site-association` y `assetlinks.json`, firmar enlaces en backend y añadir expiración. QR contiene sólo URL firmada, nunca secretos. Push usa APNs/FCM mediante Expo Notifications; almacenar tokens por instalación, preferencias, expiración y recibos.

## Operación

- Ambientes aislados dev/staging/prod y datos sintéticos fuera de producción.
- CI: lint, tests, SBOM, escaneo, build reproducible, canary 5→25→100% y rollback.
- Dashboards: conexiones, latencia p95/p99, errores, desincronización, reconexiones y abuso.
- Versiones mínimas controladas por backend; actualizaciones críticas bloquean con mensaje claro.
- Soporte con SLA, tickets, apelación y trazabilidad.

## Pendientes antes de distribución

- Completar persistencia y autenticación (el prototipo usa estado en memoria e invitado).
- Terminar el tablero visual y todas las reglas de Dominó.
- Añadir chat moderado, push real, QR scanner y universal links con dominio final.
- Ejecutar pruebas de carga, pentest, privacidad y revisión de tiendas.
- Aportar cuentas, certificados, dominio, logos, textos legales y datos de soporte.
