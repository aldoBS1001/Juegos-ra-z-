# Seguridad, cumplimiento y riesgos

## Bloqueo económico del MVP

`REAL_MONEY_ENABLED=false` es condición de arranque. El cliente declara `moneyFeatures:false`; la API rechaza `/money/*`; no existen pantallas de depósito, retiro o apuesta; no hay contratos desplegados. Producción debe añadir policy-as-code que impida cambiar esta bandera sin un release firmado y aprobación dual.

## Controles

- OIDC/PKCE, access tokens cortos y refresh token rotatorio en Keychain/Keystore.
- MFA obligatorio, RBAC/ABAC y doble aprobación para administradores.
- TLS 1.3, cifrado KMS, secretos rotados, WAF, rate limit y protección DDoS.
- App Attest/DeviceCheck y Play Integrity; señales de root/jailbreak sin depender sólo de ellas.
- Eventos append-only, hashes de auditoría, retención y acceso mínimo.
- Anti-cheat: servidor autoritativo, secuencia monótona, idempotencia, detección de colusión y bots.
- Privacidad: minimización, consentimiento versionado, derechos ARCO, borrado y residencia evaluada.

## Matriz de habilitación (no constituye opinión jurídica)

| Función | MVP MX/LATAM | Requisito antes de activar |
|---|---:|---|
| Juego social gratuito | Sí | Privacidad, términos, edad y moderación |
| Premios sin valor | Sí, revisado | Reglas publicadas y protección al consumidor |
| Entrada/premio monetario | No | Dictamen local, licencia, geolocalización, KYC/AML, tienda y pagos |
| Cripto/escrow | No | Lo anterior + custodio/proveedor, Travel Rule si aplica y auditoría contractual |
| Referido remunerado | No | Legalidad publicitaria/afiliación, antifraude e impuestos |
| Trading real | No | Licencias financieras y proveedor regulado; fuera del alcance |

La matriz por país/estado debe ser firmada por asesor local antes de lanzamiento. Cripto no cambia la clasificación jurídica del juego.

## Diseño económico futuro

Libro mayor de doble entrada, montos decimales enteros por unidad mínima, claves de idempotencia y conciliación diaria. Comisión: `fee = gross × basisPoints / 10,000`; 1,000 bps = 10%. Se congela en el snapshot de reglas antes de aceptar la entrada y nunca cambia retroactivamente. Fondos de usuario, premios, operación y comisión se separan contable y custodialmente.

Wallets futuras: proveedor institucional con MPC/HSM, multifirma, allowlists, límites, approvals, pausas, conciliación on/off-chain y cero semillas/llaves privadas en el producto. WalletConnect opcional; cada firma muestra red, activo, contrato, monto y efecto.

## Riesgos principales

| Riesgo | Severidad | Mitigación/gate |
|---|---|---|
| Operar juego con dinero sin licencia | Crítica | Deny-by-default por jurisdicción y dictamen firmado |
| Robo o pérdida de fondos | Crítica | No custodia MVP; custodio regulado + MPC + auditoría futura |
| Manipulación de resultado | Alta | CSPRNG servidor, commit-reveal/VRF futuro, logs y pruebas |
| Colusión/bots/cuentas múltiples | Alta | Grafos, device intelligence, límites y revisión humana |
| Menores o usuarios vulnerables | Alta | Edad, límites, pausas, autoexclusión y soporte |
| Rechazo Apple/Google | Alta | Binario social separado; revisión previa y geofencing aprobado |
| Fuga de datos | Alta | Minimización, cifrado, DLP, pentest y respuesta a incidentes |

## Incidentes

Severidad SEV-1 a SEV-4, guardia, freeze de partidas, comunicación, preservación de evidencia y postmortem sin culpa. RTO 60 min/RPO 5 min para partidas; backups cifrados y restauración trimestral.
