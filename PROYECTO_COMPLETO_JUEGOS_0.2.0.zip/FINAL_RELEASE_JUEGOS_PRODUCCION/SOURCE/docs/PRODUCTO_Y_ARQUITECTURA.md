# Documento maestro de producto y arquitectura

## Alcance entregado

MVP social gratuito para iOS y Android con una base web administrativa y backend compartido. Incluye creación/unión de salas, mínimo de cuatro jugadores, servidor autoritativo, sincronización, reconexión, Lotería 6×5, Toma Todo y cimiento de Dominó. No incluye dinero real ni custodia.

## Arquitectura

```mermaid
flowchart TB
  M[React Native iOS/Android] --> E[API Edge + TLS]
  A[Panel Next.js] --> E
  E --> G[NestJS REST + Socket.IO]
  G --> P[(PostgreSQL)]
  G --> R[(Redis: presencia y snapshots)]
  G --> Q[Cola de eventos]
  Q --> N[Notificaciones y auditoría]
```

Para producción: Cloudflare delante de un balanceador AWS; servicios en ECS/Fargate al inicio y EKS sólo al justificarlo por escala. Aurora PostgreSQL Multi-AZ, ElastiCache Redis, S3 cifrado, CloudFront, SQS/EventBridge, Secrets Manager, WAF y observabilidad con OpenTelemetry. La sala es una unidad de afinidad; Redis guarda presencia y el snapshot durable va a PostgreSQL.

## Decisiones

| Área | Selección | Razón |
|---|---|---|
| Móvil | Expo + React Native + TypeScript | Una base iOS/Android, builds EAS, módulos nativos disponibles |
| Tiempo real | Socket.IO sobre WebSocket | Reconexión, acknowledgements, rooms y fallback |
| API | NestJS | Módulos, validación, guards y pruebas |
| Datos | PostgreSQL + Prisma | Consistencia, auditoría y migraciones tipadas |
| Estado efímero | Redis | Presencia, rate limit, locks y fan-out |
| Panel | Next.js | SSR, RBAC y operación web |

## Flujo autoritativo

```mermaid
sequenceDiagram
  participant C as Cliente
  participant S as Servidor de juego
  participant D as Estado durable
  C->>S: acción + matchId + secuencia
  S->>S: autenticar, validar turno y regla
  S->>D: evento idempotente
  S-->>C: nuevo estado + secuencia
  Note over C,S: El cliente sólo anima el resultado firmado por el servidor
```

## Escala de 4 a 1,000 participantes

- 4–10: una room Socket.IO, snapshot al finalizar cada turno.
- 100: proceso de partida con afinidad, Redis adapter y diffs compactos.
- 500: canales separados para estado, chat y presencia; backpressure y espectadores.
- 1,000: broadcaster por evento, actualizaciones agrupadas, CDN para medios y ensayo a 2,000 conexiones/evento.
- Objetivos: p95 de acción a confirmación <250 ms regional; recuperación <3 s; disponibilidad 99.9% MVP/99.95% eventos.

## UX/UI móvil

Identidad contemporánea mexicana sin estética de casino: terracota, maíz, bugambilia, jade y crema. Navegación inferior: Inicio, Explorar, Amigos, Actividad, Perfil. Objetivos táctiles ≥44 pt, VoiceOver/TalkBack, texto dinámico y alto contraste.

```mermaid
flowchart TD
  I[Inicio: jugar rápido] --> L[Lobby y filtros]
  L --> S[Sala por código o QR]
  S --> J[Mesa de juego]
  J --> R[Resultado y compartir]
  R --> H[Historial]
```

Lotería: cartón 6×5 con marcación manual/automática, carta actual fija e historial deslizable. Toma Todo: ruleta sólo visual después de recibir el resultado. Dominó: mano inferior, jugadas válidas resaltadas, confirmación y deshacer selección. El panel separa Resumen, Usuarios, Salas, Eventos, Campañas, Riesgo, Auditoría y Configuración.

## Roadmap

1. Semanas 1–4: identidad, cuentas, persistencia real, sala y telemetría.
2. Semanas 5–8: completar reglas/UX de tres juegos, chat seguro, QR/deep links y push.
3. Semanas 9–12: QA, carga, accesibilidad, moderación, TestFlight y Google Play interno.
4. Fase 2: eventos, torneos, rankings y transparencia verificable.
5. Sólo después de licencias: módulo económico separado y auditado.

## Presupuesto cloud orientativo

MVP cerrado: USD 500–1,500/mes. Piloto regional: USD 2,000–6,000/mes. Eventos frecuentes de 1,000 concurrentes: USD 6,000–20,000/mes según retención, tráfico, observabilidad y soporte. No incluye personal, proveedores KYC, abogados, auditorías ni comisiones de tiendas.
